package game

/**
  * Created by Allu on 11/11/2016.
  */
trait C_Locatable {
    var location: Location
}