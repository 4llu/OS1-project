package game

import java.awt.image.BufferedImage

/**
  * Created by Allu on 11/11/2016.
  */
trait C_Drawable extends C_Locatable {
    var sprite: BufferedImage
    var remove = false

    // TODO Sprite list for different actions
}
